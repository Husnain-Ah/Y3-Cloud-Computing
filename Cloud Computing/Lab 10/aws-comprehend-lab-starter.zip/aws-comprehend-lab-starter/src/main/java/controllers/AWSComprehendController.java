package controllers;

public class AWSComprehendController {
	
	public static void main(String[] args) {
		// do something here....
	}

}
