package utils;

public class AWSComprehendUtils {
	
	private static final String AWS_ACCESS_KEY_ID = "YOUR_ACCESS_KEY";
	private static final String AWS_SECRET_KEY = "YOUR_SECRECT_KEY";

}
