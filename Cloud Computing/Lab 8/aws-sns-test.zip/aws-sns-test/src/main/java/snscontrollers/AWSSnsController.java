package snscontrollers;

public class AWSSnsController {

	public static void main(String[] args) {
		
		// TEST YOUR FUNCTIONS HERE.. 
		
	}

}