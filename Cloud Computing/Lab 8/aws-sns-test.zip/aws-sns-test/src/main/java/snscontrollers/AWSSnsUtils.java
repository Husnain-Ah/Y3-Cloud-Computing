package snscontrollers;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClient;

public class AWSSnsUtils {
	
	private static final String AWS_ACCESS_KEY_ID = "YOUR_ACCESS_KEY";
	private static final String AWS_SECRET_KEY = "YOUR_SECRECT_KEY";
	
	private AmazonSNS snsClient;
	
	public AWSSnsUtils() {
		snsClient = AmazonSNSClient.builder().withRegion(Regions.US_EAST_1)
				.withCredentials(new AWSStaticCredentialsProvider(
						new BasicAWSCredentials(AWS_ACCESS_KEY_ID, AWS_SECRET_KEY)))
				.build();
	}

}
