package controllers;

import utils.AWSRekoginitionUtils;

public class AWSRekogitionController {

	public static void main(String[] args) {

		AWSRekoginitionUtils utils = new AWSRekoginitionUtils();
		
	}

}