package utils;

public class AWSRekoginitionUtils {

	private static final String AWS_ACCESS_KEY_ID = "YOUR_KEY";
	private static final String AWS_SECRET_KEY = "YOUR_SECRET";
	
	
}
